# BobVisual Launcher — Android starter

This is a **starter project**, not a finished Minecraft launcher or a compiled APK.

## What is included
- Kotlin + Jetpack Compose Android project
- BobVisual dark purple/blue UI
- Home, Versions, Account, and Settings tabs
- Version selection UI and clear setup/status messages

## What is not included
- Minecraft Bedrock game engine or game files
- Downloading arbitrary historical Bedrock versions
- Microsoft/Xbox authentication implementation
- Launching the Bedrock runtime
- A compiled APK

Minecraft Bedrock is proprietary software. Do not bundle or redistribute its game files without authorization. Version availability and installation depend on official distribution, device compatibility, and licensing. A Microsoft password should never be collected directly by the launcher.

## Build
1. Open this folder in Android Studio.
2. Use JDK 17 and install Android SDK 35.
3. Let Gradle sync.
4. Select `app` and choose **Build > Build APK(s)**.

The debug APK will normally appear at:
`app/build/outputs/apk/debug/app-debug.apk`

## Package details
- Application ID: `com.bobvisual.launcher`
- Version: `0.1.0`
- Minimum Android: API 26 (Android 8.0)

## Next implementation milestones
1. Confirm the supported, authorized Bedrock install/launch mechanism for target Android devices.
2. Add a version catalog only for builds the user is entitled to obtain.
3. Implement official sign-in using a supported OAuth flow, if available and permitted.
4. Test install/launch on real Android devices and handle failures.
