package com.bobvisual.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF090A12)
private val Panel = Color(0xFF171A2A)
private val Purple = Color(0xFF8055FF)
private val Blue = Color(0xFF26B7F2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BobVisualApp() }
    }
}

@Composable
fun BobVisualApp() {
    var page by remember { mutableStateOf("Home") }
    var selectedVersion by remember { mutableStateOf("Installed game") }
    var status by remember { mutableStateOf("Ready") }
    val versions = listOf(
        "Latest stable (official install)",
        "Installed game",
        "Version list — integration needed"
    )

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Night, surface = Panel, primary = Purple,
            secondary = Blue, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Night,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    NavigationBarItem(
                        selected = page == "Home", onClick = { page = "Home" },
                        icon = { Icon(Icons.Default.Gamepad, null) }, label = { Text("Home") }
                    )
                    NavigationBarItem(
                        selected = page == "Versions", onClick = { page = "Versions" },
                        icon = { Icon(Icons.Default.Download, null) }, label = { Text("Versions") }
                    )
                    NavigationBarItem(
                        selected = page == "Account", onClick = { page = "Account" },
                        icon = { Icon(Icons.Default.Person, null) }, label = { Text("Account") }
                    )
                    NavigationBarItem(
                        selected = page == "Settings", onClick = { page = "Settings" },
                        icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") }
                    )
                }
            }
        ) { padding ->
            when (page) {
                "Home" -> HomeScreen(padding, selectedVersion, status) { status = it }
                "Versions" -> VersionsScreen(padding, versions, selectedVersion) {
                    selectedVersion = it
                    status = "Selected: $it"
                }
                "Account" -> InfoScreen(padding, "Microsoft / Xbox account",
                    "Account sign-in is not connected in this starter. Add the official supported authentication flow; never collect or store a Microsoft password in this app.")
                else -> InfoScreen(padding, "Settings",
                    "BobVisual Launcher starter • v0.1.0\n\nTheme: Dark purple / blue\n\nGame runtime and official version integration are not included yet.")
            }
        }
    }
}

@Composable
fun HomeScreen(padding: PaddingValues, version: String, status: String, onLaunch: (String) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Text("BOBVISUAL", fontSize = 14.sp, color = Blue, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Spacer(Modifier.height(8.dp))
            Text("Launcher", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text("Your Bedrock hub", fontSize = 16.sp, color = Color.LightGray)
        }
        item {
            Box(
                modifier = Modifier.fillMaxWidth().height(190.dp)
                    .background(Brush.linearGradient(listOf(Purple, Color(0xFF292D72), Blue)), RoundedCornerShape(28.dp))
                    .padding(22.dp),
                contentAlignment = Alignment.BottomStart
            ) {
                Column {
                    Text("MINECRAFT", fontSize = 25.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("BEDROCK EDITION", fontSize = 12.sp, color = Color.White, letterSpacing = 2.sp)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Selected profile", color = Color.LightGray, fontSize = 13.sp)
                    Text(version, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Status: $status", color = Blue, fontSize = 13.sp)
                    Button(
                        onClick = { onLaunch("Launch integration not connected. Install the official game first.") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple),
                        shape = RoundedCornerShape(14.dp)
                    ) { Icon(Icons.Default.Gamepad, null); Spacer(Modifier.width(8.dp)); Text("PLAY") }
                    Text("Play currently shows a setup notice; the Bedrock game engine cannot be bundled by this starter.", color = Color.LightGray, fontSize = 12.sp)
                }
            }
        }
        item {
            Text("Quick actions", fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickCard("Versions", "Choose build", Modifier.weight(1f))
                QuickCard("Account", "Sign-in setup", Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun QuickCard(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(subtitle, fontSize = 12.sp, color = Color.LightGray)
        }
    }
}

@Composable
fun VersionsScreen(padding: PaddingValues, versions: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
        Text("Versions", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(8.dp))
        Text("Choose a profile. Actual version discovery/download requires an authorized Bedrock distribution integration.", color = Color.LightGray)
        Spacer(Modifier.height(18.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(versions) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onSelect(item) },
                    colors = CardDefaults.cardColors(containerColor = if (selected == item) Color(0xFF292044) else Panel),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(item, fontWeight = FontWeight.SemiBold)
                            Text(if (selected == item) "Selected" else "Tap to select", color = Color.LightGray, fontSize = 12.sp)
                        }
                        if (selected == item) Text("✓", color = Blue, fontSize = 20.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun InfoScreen(padding: PaddingValues, title: String, body: String) {
    Column(
        Modifier.fillMaxSize().padding(padding).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Text(body, color = Color.LightGray, lineHeight = 23.sp)
    }
}
